export class MyClass {
}
